CONTRIBUTIONS 
Alexander Earl
-> Custom User Model/Admin, Sign In/Sign Up, Filtering, Profile Page, Similar Hobbies
Bishes Limbu
-> Custom User Model/Admin, Sign In/Sign Up, Filtering, Similar Hobbies, Profile Page
Samuele Joshi
-> Friend Requests, Friends, Hobbies List, Similar Hobbies
Yat Syn Chan
-> Friend Requests, Friends, Hobbies List, Similar Hobbies


URL -> https://group30-2021-group30-2021.apps.kube.eecs.qmul.ac.uk/


ADMIN ACCOUNT:
Username: admin
Password: 1234


TEST USERS:
Username: bradleySmith
Password: keyboard21

Username: alexe99
Password: 99password99

Username: bish
Password: bish1234

Username: peterParker
Password: spiderman2077

Username: harry10
Password: kanespurs

Username: gwenStacey
Password: staceylol2


Program Disclaimer:
Friend request button doesn't appear on some users in the similar users page, it is not broken.
the button does not appear due to the user either: 
1. Already being friends with the other user.
2. Received a friend request from the other user.
3. Sent a friend request already. 

Program Disclaimer:
Sign out before signing into DJANGO backend admin page. 
Sign out on the DJANGO back end admin page before signing back into a regular user on the frontend.


